// SPDX-License-Identifier: GPL-3.0
pragma solidity ^0.8.0;

contract GovernedPrivacyLayer {
    uint256 public alpha = 50;
    uint256 public noiseFactor;
    bool public anomalyMode;

    function simulate(uint256 testAlpha, uint256 noise, bool anomaly) public pure returns (uint256) {
        int256 diff = int256(testAlpha) - 50;
        uint256 base = 62 - (52 * uint256(diff * diff)) / 2500;

        if (anomaly) {
            base = base > 15 ? base - 15 : 0;
        }

        return base + noise;
    }
}
