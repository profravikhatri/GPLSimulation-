const fs = require("fs");

const simulated = JSON.parse(fs.readFileSync("data/simulation_results.json"));
const dataset = fs.readFileSync("data/gpl_5000_runs_dataset.csv", "utf-8");

function parseCSV(csv) {
  const lines = csv.trim().split("\n").slice(1);
  return lines.map(line => {
    const cols = line.split(",");
    return {
      conflict: Number(cols[5])
    };
  });
}

function mean(arr) {
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

const simMean = mean(simulated.map(x => x.conflictReduction));
const dataMean = mean(parseCSV(dataset).map(x => x.conflict));

console.log("Simulation Mean:", simMean);
console.log("Dataset Mean:", dataMean);
console.log("Difference:", Math.abs(simMean - dataMean));
