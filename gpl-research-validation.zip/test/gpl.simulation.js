const { ethers } = require("hardhat");
const fs = require("fs");

describe("GPL Simulation", function () {
  let gpl;

  before(async function () {
    const GPL = await ethers.getContractFactory("GovernedPrivacyLayer");
    gpl = await GPL.deploy();
  });

  it("Run 5000 simulations", async function () {
    let results = [];

    for (let i = 0; i < 5000; i++) {
      let alpha = Math.floor(Math.random() * 81) + 20;
      let noise = Math.floor(Math.random() * 5);
      let anomaly = Math.random() < 0.07;

      const value = await gpl.simulate(alpha, noise, anomaly);

      results.push({
        run: i + 1,
        alpha,
        noise,
        anomaly,
        conflictReduction: Number(value)
      });
    }

    fs.writeFileSync("data/simulation_results.json", JSON.stringify(results, null, 2));
  });
});
